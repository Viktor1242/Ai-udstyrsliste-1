import { useState } from "react";

export default function App() {
  const [title, setTitle] = useState("");
  const [info, setInfo] = useState("");
  const [equipment, setEquipment] = useState("");
  const [output, setOutput] = useState("");

  const generateText = () => {
    const response = `
🚘 ${title || "Bil"} – Eksklusiv komfort og stil ⚡

${info || "En moderne bil med alt i udstyr – perfekt til leasing, erhverv eller privat luksus."}

✨ Højdepunkter fra udstyrslisten:
${equipment
  .split("\n")
  .map((item) => "- " + item.trim())
  .join("\n")}

👉 En bil for dig, der vil have komfort, design og teknologi samlet i ét.
    `;
    setOutput(response);
  };

  return (
    <div className="p-8 max-w-3xl mx-auto font-sans">
      <h1 className="text-2xl font-bold mb-4">Flexlease AI Generator</h1>

      <label className="block mb-2 font-medium">Titel (fx Mercedes EQV 300 L)</label>
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="border rounded w-full p-2 mb-4"
      />

      <label className="block mb-2 font-medium">Ekstra info (fx moms/afgift, farve, leasing-info)</label>
      <textarea
        value={info}
        onChange={(e) => setInfo(e.target.value)}
        className="border rounded w-full p-2 mb-4"
        rows={3}
      />

      <label className="block mb-2 font-medium">Udstyrsliste</label>
      <textarea
        value={equipment}
        onChange={(e) => setEquipment(e.target.value)}
        className="border rounded w-full p-2 mb-4"
        rows={8}
        placeholder="Indsæt udstyr her..."
      />

      <button
        onClick={generateText}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Generér beskrivelse
      </button>

      {output && (
        <div className="mt-6 border-t pt-4 whitespace-pre-wrap">
          <h2 className="text-xl font-bold mb-2">Resultat</h2>
          <p>{output}</p>
        </div>
      )}
    </div>
  );
}